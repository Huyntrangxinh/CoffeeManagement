from flask import Flask, render_template, request
from controller.menu_controller import MenuController

app = Flask(__name__)

# Route for displaying the menu
@app.route("/")
def show_menu():
    controller = MenuController()
    return controller.request_menu()

# Route for editing a menu item
@app.route("/menu/edit/<int:item_id>", methods=["GET"])
def edit_menu(item_id):
    controller = MenuController()
    return controller.edit_menu(item_id)

# Route for updating a menu item
@app.route("/menu/update/<int:item_id>", methods=["POST"])
def update_menu(item_id):
    controller = MenuController()
    return controller.update_menu(item_id)

# Admin system routes
@app.route("/admin/menu/list")
def show_menu_list():
    controller = MenuController()
    return controller.list_menu()

@app.route("/admin/menu/create")
def create_menu():
    controller = MenuController()
    return controller.create_menu()

@app.route("/admin/menu/store", methods=["POST"])
def store_menu():
    controller = MenuController()
    return controller.store_menu()
@app.route("/menu/remove/<int:item_id>", methods=["GET"])
def remove_menu(item_id):
    controller = MenuController()
    return controller.delete_menu(item_id)

if __name__ == "__main__":
    app.run(debug=True)
